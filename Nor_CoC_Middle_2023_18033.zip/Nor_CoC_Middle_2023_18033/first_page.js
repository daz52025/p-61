function change() {
    window.location = "main_page.html";
}
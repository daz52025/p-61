Webcam.set({
    width: 350,
    height: 300,
    image_format: 'png',
    png_quality: 100
});

var cam = document.getElementById("camera");
Webcam.attach(cam);

function take_snapshot() {
    Webcam.snap(function (snapshot) {
        document.getElementById("result").innerHTML = '<img id="cap_img" src="' + snapshot + '">';
    })
}

console.log("ml5 version = ", ml5.version);

var classifyer = ml5.imageClassifier('https://teachablemachine.withgoogle.com/models/QPiZ-Gxoi/model.json', modelLoaded);

function modelLoaded() {
    console.log("model has been loaded successfully 👍🏻");
}

function check_img() {
    var cap = document.getElementById("cap_image");
    classifyer.classify(cap, gotResult);
}

function gotResult(error, results) {
    if (error) {
        console.error(error);
    }
    else {
        console.log(results);
        document.getElementById("obj_name").innerHTML = results[0].label;
        document.getElementById("acc").innerHTML = results[0].confidence.toFixed(5);
    }
}
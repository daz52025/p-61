function oddorevenchecker(){

    var num = document.getElementById("num").value;
    if(num == 1){
        window.alert("this is a odd number");
    }
    else if(num == 2){
        window.alert("this is a even number");
    }
    else if(num == 3){
        window.alert("this is a odd number");
    }
    else if(num == 4){
        window.alert("this is a even number");
    }
    else if(num == 5){
        window.alert("this is a odd number");
    }
    else if(num == 6){
        window.alert("this is a even number");
    }
    else if(num == 7){
        window.alert("this is a odd number");
    }
    else if(num == 8){
        window.alert("this is a even nnumber");
    }
    else if(num == 9){
        window.alert("this is a odd number");
    }
    else if(num == 10){
        window.alert("this is a even number");
    }
    else if(num == 11){
        window.alert("this is a odd nnumber");
    }
    else{
        window.alert("this is odd there seems to be a misunderstanding about the numbers i will have to check with the creator of this website or maybe you may have written an Invalid numbers , Please wait");
    }
}

function positiveornegativechecker(){

    var no = document.getElementById("no").value;
    if(no == 1){
        window.alert("this is a positive number");
    }
    else if(no == 2){
        window.alert("this is a positive number");
    }
    else if(no == 3){
        window.alert("this is a positive number");
    }
    else if(no == 4){
        window.alert("this is a positive number");
    }
    else if(no == 5){
        window.alert("this is a positive number");
    }
    else if(no == 6){
        window.alert("this is a positive numberr");
    }
    else if(no == 7){
        window.alert("this is a positive number");
    }
    else if(no == 8){
        window.alert("this is a positive number");
    }
    else if(no == 9){
        window.alert("this is a positive nnumberr");
    }
    else if(no == 10){
        window.alert("this is a positive number");
    }
    else if(no == -1){
        window.alert("this is a negative nnumber");
    }
    else if(no == -2){
        window.alert("this is a negative nnumberr");
    }
    else if(no == -3){
        window.alert("this is a negative number");
    }
    else if(no == -4){
        window.alert("this is a negative number");
    }
    else if(no == -5){
        window.alert("this is a negative number");
    }
    else if(no == -6){
        window.alert("this is a negative number");
    }
    else if(no == -7){
        window.alert("this is a negative number");
    }
    else if(no == -8){
        window.alert("this is a negative nnumber");
    }
    else if(no == -9){
        window.alert("this is a negative nnumberr");
    }
    else if(no == -10){
        window.alert("this is a negative nonumberr");
    }      
    else{
        window.alert("this is odd there seems to be a misunderstanding about the numbers i will have to check with the creator of this website or maybe you may have written an Invalid numbers , Please wait");
    }
}

function voteeligchecker(){

    var nos = document.getElementById("nos").value;
    if(nos == 1){
        window.alert("this person is not elligeble for voting");
    }
    else if(nos == 2){
        window.alert("this person is not elligeble for voting");
    }
    else if(nos == 3){
        window.alert("this person is not elligeble for voting");
    }
    else if(nos == 4){
        window.alert("this person is not elligeble for voting");
    }
    else if(nos == 5){
        window.alert("this person is not elligeble for voting");
    }
    else if(nos == 6){
        window.alert("this person is not elligeble for voting");
    }
    else if(nos == 7){
        window.alert("this person is not elligeble for voting");
    }
    else if(nos == 8){
        window.alert("this person is not elligeble for voting");
    }
    else if(nos == 9){
        window.alert("this person is not elligeble for voting");
    }
    else if(nos == 10){
        window.alert("this person is not elligeble for voting");
    }
    else if(nos == 11){
        window.alert("this person is not elligeble for voting");
    }
    else if(nos == 12){
        window.alert("this person is not elligeble for voting");
    }
    else if(nos == 13){
        window.alert("this person is not elligeble for voting");
    }
    else if(nos == 14){
        window.alert("this person is not elligeble for voting");
    }
    else if(nos == 15){
        window.alert("this person is not elligeble for voting");
    }
    else if(nos == 16){
        window.alert("this person is not elligeble for voting");
    }
    else if(nos == 17){
        window.alert("this person is not elligeble for voting");
    }
    else if(nos == 18){
        window.alert("this person is elligeble for voting");
    }
    else if(nos == 19){
        window.alert("this person is elligeble for voting");
    }
    else if(nos == 20){
        window.alert("this person is elligeble for voting");
    }
    else if(nos == 21){
        window.alert("this person is elligeble for voting");
    }
    else if(nos == 22){
        window.alert("this person is elligeble for voting");
    }
    else if(nos == 23){
        window.alert("this person is elligeble for voting");
    }
    else if(nos == 24){
        window.alert("this person is elligeble for voting");
    }
    else if(nos == 25){
        window.alert("this person is elligeble for voting");
    }
    else{
        window.alert("this is odd there seems to be a misunderstanding about the numbers i will have to check with the creator of this website or maybe you may have written an Invalid number , Please wait")
    }
}


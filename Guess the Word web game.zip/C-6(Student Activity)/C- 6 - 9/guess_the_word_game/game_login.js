function addplayer(){
    var p1name = document.getElementById("p1").value;
    var p2name = document.getElementById("p2").value;

    localStorage.setItem("Player1" , p1name);
    localStorage.setItem("Player2" , p2name);

    window.location = "game_page.html";
}
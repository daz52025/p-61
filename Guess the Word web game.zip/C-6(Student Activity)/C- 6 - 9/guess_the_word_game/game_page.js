player1 = localStorage.getItem("Player1");
player2 = localStorage.getItem("Player2");

p1score = 0;
p2score = 0;

document.getElementById("pl1").innerHTML = player1 + " - ";
document.getElementById("pl2").innerHTML = player2 + " - ";

document.getElementById("p1score").innerHTML = p1score;
document.getElementById("p2score").innerHTML = p2score;

document.getElementById("qturn").innerHTML ="Question turn - " + player1 ;
document.getElementById("aturn").innerHTML ="Answer turn - " + player2 ;

function sendwrd(){
   wbox = document.getElementById("wbox").value;
   word = wbox.toLowerCase();

   ch1 = word.charAt(0);
   console.log(ch1);

   cln = Math.floor(word.length/3);
   ch2 =  word.charAt(cln);
   console.log(ch2);

   csub = word.length-2;
   ch3 =  word.charAt(csub);
   console.log(ch3);

   rep1 = word.replace(ch1,"_");
   rep2 = rep1.replace(ch2,"_");
   rep3 = rep2.replace(ch3,"_");
   console.log("rep3");

   Qn = "<h4 id = 'q'>Q." + rep3 + "</h4>";
   inp = "<br> Answer : <input type = 'text' id = 'ans'></input>";
   btn = "<br> <br> <button class = 'btn btn-info' onclick = 'check()'>Check</button>";
   total = Qn + inp + btn; 
   document.getElementById("result").innerHTML = total;

   document.getElementById("wbox").value = "";
}
qturn = "player 1";
aturn = "player 2";

function check(){
    
    abox = document.getElementById("ans").value;
    ans = abox.toLowerCase();

    if(ans == word){
        if(aturn == "player 1"){
            window.alert("Congratulations🥳! You answered it correct😃");
            p1score = p1score + 1;
            document.getElementById("p1score").innerHTML = p1score;
        }
        else{
            window.alert("Congratulations🥳! You answered it correct😃");
            p2score = p2score + 1;
            document.getElementById("p2score").innerHTML = p2score;
        } 
        
    }
    else{
        if(aturn == "player 1"){
            window.alert("Aww man You Were So close Better luck Next time😭😥☹️🥺");
            p1score = p1score - 1;
            document.getElementById("p1score").innerHTML = p1score;
        }
        else{
            window.alert("Aww man You Were So close Better luck Next time😭😥☹️🥺");
            p2score = p2score - 1;
            document.getElementById("p2score").innerHTML = p2score;
        } 
    }

    

    if(qturn == "player 2"){
        qturn = "player 1"; 
        document.getElementById("qturn").innerHTML ="Question turn - " + player1;
    }
    else{
        qturn = "player 2";
        document.getElementById("qturn").innerHTML ="Question turn - " + player2; 
    }

    if(aturn == "player 1"){
        aturn = "player 2"; 
        document.getElementById("aturn").innerHTML ="Answer turn - " + player2;
    }
    else{
        aturn = "player 1";
        document.getElementById("aturn").innerHTML ="Answer turn - " + player1; 
    }
     

    document.getElementById("result").innerHTML = "";
}


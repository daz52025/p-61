function getscore(){
    score = localStorage.getItem("Score");
    document.getElementById("gscore").innerHTML = "Score : " + score;
}

function back(){
    window.location = "activity_1.html";
 }

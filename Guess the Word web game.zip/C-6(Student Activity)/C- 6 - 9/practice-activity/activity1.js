 var score = 0;

 function updtscore(){
    score = score + 1;
    document.getElementById("dispscore").innerHTML = "Score : " + score;
 }

 function storescore(){
    localStorage.setItem("Score",score);
 }

 function nextpage(){
    window.location = "activity_2.html";
 }
